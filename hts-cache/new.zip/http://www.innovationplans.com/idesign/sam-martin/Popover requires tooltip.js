<!DOCTYPE html>
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="ie ie9" lang="en"> <![endif]-->
<!--[if !IE]><!--><html lang="en-US"> <!--<![endif]-->
<head>
<!-- un-comment and delete 2nd meta below to disable zoom
<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1"> -->
<meta name="viewport" content="width=device-width, initial-scale=1" />

<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="http://www.innovationplans.com/xmlrpc.php">
<link rel="alternate" type="application/rss+xml" title="IPEC" href="http://www.innovationplans.com/feed/" />

<title>Page not found &#8211; IPEC</title>
<link rel='dns-prefetch' href='//s0.wp.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="IPEC &raquo; Feed" href="http://www.innovationplans.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="IPEC &raquo; Comments Feed" href="http://www.innovationplans.com/comments/feed/" />
<link rel='stylesheet' id='karma-builder-css'  href='http://www.innovationplans.com/wp-content/plugins/karma_builder/css/karma-builder.css?ver=4.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://www.innovationplans.com/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.5' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='style-css'  href='http://www.innovationplans.com/wp-content/themes/Karma/style.css?ver=4.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='primary-color-css'  href='http://www.innovationplans.com/wp-content/themes/Karma/css/karma-cool-blue.css?ver=4.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='http://www.innovationplans.com/wp-content/themes/Karma/css/_font-awesome.css?ver=4.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='mobile-css'  href='http://www.innovationplans.com/wp-content/themes/Karma/css/_mobile.css?ver=4.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='jetpack_css-css'  href='http://www.innovationplans.com/wp-content/plugins/jetpack/css/jetpack.css?ver=5.0' type='text/css' media='all' />
<script type='text/javascript' src='http://www.innovationplans.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script><script>jQueryWP = jQuery;</script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.5'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.5'></script>
<link rel='https://api.w.org/' href='http://www.innovationplans.com/wp-json/' />

<link rel='dns-prefetch' href='//v0.wordpress.com'>
<link rel='dns-prefetch' href='//i0.wp.com'>
<link rel='dns-prefetch' href='//i1.wp.com'>
<link rel='dns-prefetch' href='//i2.wp.com'>
<style type='text/css'>img#wpstats{display:none}</style>	<meta property="og:title" content="Cairo Festival City"/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content="http://www.innovationplans.com/cairo-festival-city/"/>
	<meta property="og:description" content=""/>
	<meta property="og:site_name" content="IPEC"/>
	<meta name="description" content="MEP Design &amp; Modeling" />
<meta name="generator" content="Powered by Slider Revolution 5.4.5 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<style type='text/css'>

.header-overlay {
	background: url(http://www.innovationplans.com/wp-content/themes/Karma/images/_global/overlay-rays.png) 50% 50% no-repeat;
}

.header-overlay {
	background-size: auto 100%;
}
</style>
<link rel="icon" href="https://i0.wp.com/www.innovationplans.com/wp-content/uploads/2017/06/cropped-favicon-32x32.png?fit=32%2C32" sizes="32x32" />
<link rel="icon" href="https://i0.wp.com/www.innovationplans.com/wp-content/uploads/2017/06/cropped-favicon-32x32.png?fit=192%2C192" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://i0.wp.com/www.innovationplans.com/wp-content/uploads/2017/06/cropped-favicon-32x32.png?fit=180%2C180" />
<meta name="msapplication-TileImage" content="https://i0.wp.com/www.innovationplans.com/wp-content/uploads/2017/06/cropped-favicon-32x32.png?fit=270%2C270" />
<script type="text/javascript">function setREVStartSize(e){
				try{ var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;					
					if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
				}catch(d){console.log("Failure at Presize of Slider:"+d)}
			};</script>

<!--[if IE 9]>
<style media="screen">
#footer,
.header-holder
 {
      behavior: url(http://www.innovationplans.com/wp-content/themes/Karma/js/PIE/PIE.php);
}
</style>
<![endif]-->

<!--[if lte IE 8]>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/themes/Karma/js/html5shiv.js'></script>
<style media="screen">
a.button,
a.button:hover,
ul.products li.product a img,
div.product div.images img,
span.onsale,
#footer,
.header-holder,
#horizontal_nav ul li,
#horizontal_nav ul a,
#tt-gallery-nav li,
#tt-gallery-nav a,
ul.tabset li,
ul.tabset a,
.karma-pages a,
.karma-pages span,
.wp-pagenavi a,
.wp-pagenavi span,
.post_date,
.post_comments,
.ka_button,
.flex-control-paging li a,
.colored_box,
.tools,
.karma_notify
.opener,
.callout_button,
.testimonials {
      behavior: url(http://www.innovationplans.com/wp-content/themes/Karma/js/PIE/PIE.php);
}
#header .header-overlay {
	background-image: none;
	filter: progid:DXImageTransform.Microsoft.AlphaImageLoader( src='http://www.innovationplans.com/wp-content/themes/Karma/images/_global/overlay-rays.png', sizingMethod='scale');
    -ms-filter: "progid:DXImageTransform.Microsoft.AlphaImageLoader( src='http://www.innovationplans.com/wp-content/themes/Karma/images/_global/overlay-rays.png', sizingMethod='scale')";
}
</style>
<![endif]-->

<!--[if IE]>
<link rel="stylesheet" href="http://www.innovationplans.com/wp-content/themes/Karma/css/_internet_explorer.css" media="screen"/>
<![endif]-->




</head>

<body class="error404 karma-body-mega-menu karma-header-gradient" itemscope="itemscope" itemtype="http://schema.org/WebPage">
<div id="tt-wide-layout" class="content-style-default">
	<div id="wrapper">
		<header role="banner" id="header" itemscope="itemscope" itemtype="http://schema.org/WPHeader" >

<div class="header-holder ">
<div class="header-overlay">
<div class="header-area error-header">

<a href="http://www.innovationplans.com" class="logo"><img src="http://www.innovationplans.com/wp-content/uploads/2017/04/IPEC-Logo-1.png" alt="IPEC" /></a>



    <nav role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
	    <ul id="menu-main-nav" class="sf-menu">
	    <li id="menu-item-19" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home"><a href="http://www.innovationplans.com/"><span><strong>Home page</strong><span class="navi-description">Front page</span></span></a></li>
<li id="menu-item-16" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://www.innovationplans.com/about/"><span><strong>About</strong><span class="navi-description">Who we are</span></span></a></li>
<li id="menu-item-17" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://www.innovationplans.com/projects/"><span><strong>Projects</strong><span class="navi-description">Achievement Works</span></span></a></li>
<li id="menu-item-18" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://www.innovationplans.com/contact-us/"><span><strong>Contact Us</strong><span class="navi-description">Get In Touch</span></span></a></li>
	    </ul>
    </nav>
</div><!-- END header-area -->
</div><!-- END header-overlay -->
</div><!-- END header-holder -->
</header><!-- END header -->


<div id="main">
    
    
	<div class="main-area">
		
<div class="tools">
	<span class="tools-top"></span>
        <div class="frame">
        <h1>Page not Found</h1><p class="breadcrumb"><a href="http://www.innovationplans.com">Home</a><span class='current_crumb'>Page not Found </span></p>        
        </div><!-- END frame -->
	<span class="tools-bottom"></span>
</div><!-- END tools -->        	
            <main role="main" id="content" class="content_full_width">
            	<div class="four_error">
                	<div class="four_message">
                    	<h1 class="four_o_four">Page not Found</h1>
							Our Apologies, but the page you are looking for could not be found. Here are some links that you might find useful:
			<ul>
			<li><a href="http://www.">Home</a></li>
			<li><a href="http://www.">Sitemap</a></li>
			<li><a href="http://www.">Contact Us</a></li>
			</ul>                    </div><!-- END four_message -->
                </div><!-- END four_error -->
            </main><!-- END main #content -->
        </div><!-- END main-area -->
        

<div id="footer-top">&nbsp;</div><!-- END footer-top -->
</div><!-- END main -->

        <footer role="contentinfo" id="footer" itemscope="itemscope" itemtype="http://schema.org/WPFooter">
        	            
            <div class="footer-overlay">
				                
                <div class="footer-content">
                    <div class="one_third tt-column"><form role="search" method="get" action="http://www.innovationplans.com/" class="search-form">
	<fieldset>
    	<label for="s">Search this website</label>
		<span class="text">
			<input type="text" name="s" class="s" id="s" value="Search" onfocus="this.value=(this.value=='Search') ? '' : this.value;" onblur="this.value=(this.value=='') ? 'Search' : this.value;" />
            <input type="submit" value="search" class="searchsubmit" />
		</span>
	</fieldset>
</form></div><div class="one_third tt-column"><h3>Expertise in</h3><div id="tagcloud"></div><script type="text/javascript" src="http://www.innovationplans.com/wp-content/themes/Karma/framework/extended/3d-tag-cloud/swfobject.js"></script><script type="text/javascript">var so = new SWFObject("http://www.innovationplans.com/wp-content/themes/Karma/framework/extended/3d-tag-cloud/tagcloud.swf", "tagcloudflash", "160", "160", "9", "#F4F4F2");so.addParam("wmode", "transparent");so.addParam("allowScriptAccess", "always");so.addVariable("tcolor", "0x333333");so.addVariable("tcolor2", "0x333333");so.addVariable("hicolor", "0x000000");so.addVariable("tspeed", "150");so.addVariable("distr", "true");so.addVariable("mode", "tags");so.addVariable("tagcloud", "%3Ctags%3E%3Ca+href%3D%22http%3A%2F%2Fwww.innovationplans.com%2Ftag%2Felectrical%2F%22+class%3D%22tag-cloud-link+tag-link-6+tag-link-position-1%22+style%3D%22font-size%3A+8pt%3B%22+aria-label%3D%22Electrical+%281+item%29%22%3EElectrical%3C%2Fa%3E%0A%3Ca+href%3D%22http%3A%2F%2Fwww.innovationplans.com%2Ftag%2Flighting%2F%22+class%3D%22tag-cloud-link+tag-link-5+tag-link-position-2%22+style%3D%22font-size%3A+8pt%3B%22+aria-label%3D%22Lighting+%281+item%29%22%3ELighting%3C%2Fa%3E%3C%2Ftags%3E");so.write("tagcloud")</script></div><div class="one_third_last tt-column"></div>                </div><!-- END footer-content -->

                            </div><!-- END footer-overlay -->  
        
        <div id="footer_bottom">
            <div class="info">
            	                <div id="foot_left">&nbsp;                    IPEC copyright 2017                    
                </div><!-- END foot_left -->
                              
                <div id="foot_right">
                           
                </div><!-- END foot_right -->
            </div><!-- END info -->
        </div><!-- END footer_bottom -->
                </footer><!-- END footer -->
        
	</div><!-- END wrapper -->
</div><!-- END tt-layout -->
	<div style="display:none">
	</div>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/plugins/jetpack/modules/photon/photon.js?ver=20130122'></script>
<script type='text/javascript' src='https://s0.wp.com/wp-content/js/devicepx-jetpack.js?ver=201805'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/plugins/karma_builder/js/bootstrap.min.js'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/plugins/karma_builder/js/appear.min.js'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/plugins/karma_builder/js/waypoints.min.js'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/plugins/karma_builder/js/easy-pie-chart.min.js'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/plugins/karma_builder/js/karma-builder.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var php_data = {"mobile_menu_text":"Main Menu","mobile_sub_menu_text":"More in this section...","mobile_horz_dropdown":"false","karma_jquery_slideshowSpeed":"8000","karma_jquery_pause_hover":"true","karma_jquery_randomize":"true","karma_jquery_directionNav":"true","karma_jquery_animation_effect":"fade","karma_jquery_animationSpeed":"600","testimonial_slideshowSpeed":"8000","testimonial_pause_hover":"false","testimonial_randomize":"false","testimonial_directionNav":"true","testimonial_animation_effect":"fade","testimonial_animationSpeed":"600","sticky_sidebar":"true","sticky_menu_one":"false","sticky_menu_two":"false"};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/themes/Karma/js/custom-main.js'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/themes/Karma/js/superfish.js'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/themes/Karma/js/retina.js'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/themes/Karma/js/jquery.flexslider.js'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/themes/Karma/js/jquery.fitvids.js'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/themes/Karma/js/jquery.isotope.js'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-includes/js/jquery/ui/tabs.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-includes/js/jquery/ui/accordion.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-content/themes/Karma/js/jquery.prettyPhoto.js'></script>
<script type='text/javascript' src='http://www.innovationplans.com/wp-includes/js/wp-embed.min.js?ver=4.8.5'></script>
<script type='text/javascript' src='https://stats.wp.com/e-201805.js' async defer></script>
<script type='text/javascript'>
	_stq = window._stq || [];
	_stq.push([ 'view', {v:'ext',j:'1:5.0',blog:'130559092',post:'0',tz:'0',srv:'www.innovationplans.com'} ]);
	_stq.push([ 'clickTrackerInit', '130559092', '0' ]);
</script>
<a href="#0" class="karma-scroll-top"><i class="fa fa-chevron-up"></i></a>
</body>
</html>
<!-- Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/

 Served from: www.innovationplans.com @ 2018-01-30 04:49:28 by W3 Total Cache -->